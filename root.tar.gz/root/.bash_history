history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
hostname
shutdown -r now
clear
apt update
clear
apt update
ping 8.8.8.8
clear
apt install nano -y
clear
vi /etc/apt/sources.list
clear
vi /etc/apt/sources.list
clear
/etc/apt/sources.list
clear
apt update
clear
vi /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
clear
apt full-upgrade -y
clear
apt-get install nano -y
clear
apt install openssh-server -y
clear
/etc/ssh/sshd_config
ls /root/Material_Adicional_TPVMCA/
CLEAR
clear
mkdir -p /root/.ssh
cat /root/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
cat /root/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
clear
nano /etc/ssh/sshd_config
clear
systemctl restart ssh
systemctl enable ssh
ssh-keygen
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
ls /root/.ssh/
clear
apt-get install apache2 php libapache2-mod-php
clear
systemctl enable apache2
systemctl start apache2
systemctl status apache2
clear
cp /root/index.php /var/www/html
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html
ls /var/www/html/
clear
apt install mariadb-server -y
clear
systemctl enable mariadb 
systemctl start mariadb 
systemctl status mariadb
clear
mysql_secure_installation
clear
mysql -u root -p < /root/Material_Adicional_TPVMCA/db.sql
mysql -u root -p "SHOW DATABASES;"
mysql -u root -p 
CLEAR
CLEAR
clear
ip a
ip route
clear
nano /etc/network/interfaces
clear
systemctl restart networking
ip a
clear
nano /etc/apache2/sites-available/000-default.conf
clear
nano /etc/apache2/apache2.conf
clear
systemctl restart apache2
cls
clear
blkid
clear
chmod 755/www_dir
clear
chmod 755 /www_dir
chown -R www-data:www-data /www_dir
apt-get install php-mysqli -y 
clear
systemctl restart apache2
clear
chmod 755 /www_dir
chmod 644 /www_dir/index.php
chmod 644 /www_dir/index.php
clear
df -h
clear
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
clear
chmod 755 /www_dir
chmod 644 /www_dir/index.php
chmod 644 /www_dir/logo.png
clear
blkid
clear
nano /etc/fstab
clear
mount -a
clear
nano /etc/fstab
clear
mount -a
cat -n /etc/fstab
clear
nano /etc/fstab
clear
tail -3 /etc/fstab
mount -a
cat -n /etc/fstab
nano /etc/fstab
cleat
clear
echo "UUID=$(blkid -s UUID -o value /dev/sdc1) /www_dir ext4 defaults 0 2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2) /backup_dir ext4 defaults 0 2" >> /etc/fstab
tail -3 /etc/fstab
mount -a
clear
reboot
clear
df -h
cat -n /etc/fstab
ls /
clear
mount -a
df -h
mount /www_dir
blkid
clear
lsblk+
clear
lsblk
df -h
clear
nano /etc/fstab
clear
reboot
